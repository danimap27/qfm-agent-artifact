# Q1 grid — QC report (phase D)

Frozen: 2026-10-01. Scope: the full Q1 grid — 90 cells, 10 seeds, 3 models
(qwen3.5, llama3.1:8b, gemma3:27b), 3 templates (t1/t2/t3), 6 conditions.
Executed on the two-node split (Titan V: 30 cells; gpu-pc 2x RTX 3090: 60
cells) with single-writer fetches and cell-level resume.

## Gate 1 — Cell completeness: PASS

- 90/90 cells present with COMPLETO markers.
- 55,080 records = 90 cells x 612 records, exactly.
- 5,508 records per seed (102 requests x 6 conditions x 9 cells/seed); the
  frozen payloads carry 102 requests per seed as built by
  `scripts/prep_grid_q1.sh` (34 per template block), so per-seed grid totals
  scale accordingly (the earlier 100-request figure in the protocol draft was
  an estimate superseded by the built payloads).
- Cell-level id audit: every one of the 90 cells has 612/612 unique
  (request_id, condition) pairs. The pooled file repeats `template_floor`
  rows across templates by construction (the deterministic floor is identical
  for t1/t2/t3); this is expected and does not affect any analysis (the floor
  enters only the six-condition Friedman block and the pairwise matrix as a
  common baseline, averaged per request).

## Gate 2 — Null audit: PASS

- Required fields: 0 nulls in request_id, condition, llm_model, seed,
  template, unsupported_rate, seconds across all 55,080 records.
- contradiction_rate nulls are structural (records with no checkable claims,
  n_checks = 0): single_block 5,483/9,180; free 35/9,180; grounded 2/9,180;
  the remaining conditions 0. The metric family tests drop null pairs, as
  specified in the pre-registered analysis plan.
- Parse-fail rate (empty parsed explanation): 0/55,080 = 0.000%.

## Gate 3 — Playback: PASS

- 100 random prompt hashes (LLM records only) recomputed from the stored
  messages against each cell's llm_cache.jsonl: 100/100 found, 100/100 with
  byte-identical stored responses.
- The template_floor records carry no prompt hash by design (no LLM call).

## Gate 4 — Sanity: PASS

- template_floor unsupported_rate == 0.0 in every record (exact).
- free unsupported_rate == 1.0 in every record (by construction).
- grounded strictly below free in every one of the 90 model x template x seed
  cells (90/90).

## Gate 5 — Tooling: PASS

- Test suite green: 75 tests passed (includes a new regression test for
  template averaging in the paired tests).
- Manuscript lint: clean.
- Figures reproducible: rendered on both machines from identical inputs and
  pinned environments (numpy 2.5.3, scipy 1.18.1, qiskit 2.5.2, matplotlib
  3.11.2). Cross-machine hash comparison: 13/18 analysis artifacts
  (pooled metrics, stats JSON, all LaTeX tables) byte-identical; 5 of 10 PNG
  figures differ only in glyph rasterization (sub-0.1% of pixels, visually
  identical); vector PDFs unaffected.
- Results tree hash: 26c9d421db0b457078d75d57b4328685a7ad3de4871194279f3ad7d2ef90496f
  (reproduce: `find results/grid_q1 -name '*.json' -o -name '*.tex' -o -name '*.png' -o -name '*.pdf' | sort | xargs sha256sum | sha256sum`).
- Per-file sha256 list for this directory: `sha256.txt`.

## Analysis-v1 to v2 corrections (pre-freeze)

Two defects were found and fixed before freezing; the frozen evidence is the
v2 output:

1. `paired_tests`, `shapiro_diagnostics` and `pairwise_matrix` collapsed
   repeated (request, condition) keys to the last template instead of
   averaging templates per request (the pre-registered unit). Fixed via
   `average_by_request`; regression test added.
2. The fleet-model filter let the "none" (template_floor) pseudo-model leak
   into model-level outputs and starve the six-condition pairwise blocks.
   Fixed by splitting `all_rows` (with floor) from modeled rows.

All correctness statements in this report refer to the regenerated v2
analysis (stats JSON hash 36ff3775546cb37841bd51c12a9ecf73f5a802c9d0825cb5eaf51089317dbc2d).
