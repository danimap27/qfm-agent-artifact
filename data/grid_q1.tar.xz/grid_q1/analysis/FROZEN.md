# Q1 grid analysis — FROZEN (2026-10-01)

Status: **frozen**. The files under this directory are the definitive phase-D
artifacts for the Q1 grid (90 cells: Titan V 30 + gpu-pc 2x RTX 3090 60;
10 seeds; 55,080 records).

## Key outcomes (for quick reference)

- F1 unsupported_rate: min p_holm = 6.3e-197 (grounded 0.188-0.312 vs free
  1.000, dz between -5.8 and -14.5 across models).
- F2 1.2e-123 | F3 1.9e-18 | F4 0.003 | F5 2.2e-08 — all families significant.
- Sanity exact: floor = 0.0, free = 1.0, grounded < free in 90/90 cells.

## Frozen artifacts

- `pooled_metrics.json` — sha256 0539c1b4101d8935b043ad6a24aa8029be3606b0a615852ad37d09977f93e13d
- `stats/grid_stats.json` — sha256 36ff3775546cb37841bd51c12a9ecf73f5a802c9d0825cb5eaf51089317dbc2d
- `tables/*.tex` (6 files), `figures/*.pdf|*.png` (20 files), `qc-report.md`
- Per-file sha256 list: `sha256.txt`
- Results tree hash: `26c9d421db0b457078d75d57b4328685a7ad3de4871194279f3ad7d2ef90496f`
  (reproduce: `find results/grid_q1 -name '*.json' -o -name '*.tex' -o -name '*.png' -o -name '*.pdf' | sort | xargs sha256sum | sha256sum`)

## Provenance

- Repo commit: `4c0c3c8` (v2 analysis, after the template-averaging and
  floor-handling fixes; `4eb3c77`).
- Executed on the Titan V node (12 cores) and reproduced on the homelab with
  pinned environments: 13/18 artifacts byte-identical across machines; 5 of
  10 PNGs differ only in glyph rasterization (sub-0.1% of pixels; visually
  identical); vector PDFs unaffected.
- QC gates: 5/5 PASS — see `qc-report.md`.
- Figure note: the figures were regenerated after the floor-pseudo-model and
  CD-label fixes (repo commit a3382c6) on both machines; the cross-machine
  comparison pattern is unchanged (5/10 byte-identical, the rest differing
  only in glyph rasterization).
